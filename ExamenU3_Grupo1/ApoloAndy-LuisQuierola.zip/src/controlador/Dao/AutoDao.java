/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador.Dao;


import java.io.IOException;
import modelo.Auto;

/**
 *
 * @author andy
 */
public class AutoDao extends AdaptadorDao<Auto> {
    
    private Auto auto;
    
    public AutoDao() {
        super(Auto.class);
    }
    
    public Auto getAuto() {
        if (auto == null) {
            auto = new Auto();
        }
        return auto;
    }
    
    public void setAuto(Auto auto) {
        this.auto = auto;
    }
    
    public void guardar() throws IOException {
        auto.setId(generateID());
        auto.setNombre("Auto "+ auto.getId());
        this.guardar(auto);
    }
    
    private Integer generateID() {
        return listar().size() + 1;
    }

}
