/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador.Dao;

import controlador.ed.lista.ListaEnlazada;
import controlador.ed.lista.exception.PosicionException;
import controlador.ed.lista.exception.VacioException;
import java.io.IOException;
import modelo.Radar;

/**
 *
 * @author andy
 */
public class RadarDao extends AdaptadorDao<Radar> {

    private Radar radar;

    public RadarDao() {
        super(Radar.class);
    }

    public Radar getRadar() {
        if (radar == null) {
            radar = new Radar();
        }
        return radar;
    }

    public void setRadar(Radar radar) {
        this.radar = radar;
    }

    public void guardar() throws IOException, VacioException, PosicionException {
        radar.setId(generateId());
        this.guardar(radar);
    }

    private Integer generateId() {
        return listar().size() + 1;
    }

    public ListaEnlazada<Radar> listaAuto(Integer id) throws VacioException, PosicionException {
        ListaEnlazada<Radar> lista = new ListaEnlazada<>();
        ListaEnlazada<Radar> listado = listar();
        for (int i = 0; i < listado.size(); i++) {
            Radar aux = listado.get(i);
            if (aux.getIdOrigen().equals(id)) {
                lista.insertar(aux);
            }
        }
        return lista;
    }

}
