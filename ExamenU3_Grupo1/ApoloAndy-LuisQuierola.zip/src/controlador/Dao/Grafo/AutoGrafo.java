/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador.Dao.Grafo;

import controlador.Dao.AutoDao;
import controlador.Dao.RadarDao;
import controlador.Dao.RadarDao;
import controlador.ed.cola.Cola;
import controlador.ed.grafo.Adycencia;
import controlador.ed.grafo.GrafoEtiquetadoD;
import controlador.ed.grafo.GrafoEtiquetadoND;
import controlador.ed.lista.ListaEnlazada;
import controlador.ed.lista.exception.PosicionException;
import controlador.ed.lista.exception.VacioException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import modelo.Auto;
import modelo.Radar;

public class AutoGrafo {

    private GrafoEtiquetadoD<Auto> grafo;
    private ListaEnlazada<Auto> lista = new ListaEnlazada<>();

    public AutoGrafo() {
        AutoDao autoDao = new AutoDao();
        lista = autoDao.listar();
        grafo = new GrafoEtiquetadoD<>(lista.size());
        try {
            for (int i = 0; i < lista.size(); i++) {
                grafo.etiquetarVertice(i + 1, lista.get(i));
                System.out.println(lista.get(i));
            }
            System.out.println("----------------");
            llenarGrafo();
        } catch (Exception e) {
        }
    }

    public GrafoEtiquetadoD<Auto> getGrafo() {
        return grafo;
    }

    public void setGrafo(GrafoEtiquetadoD<Auto> grafo) {
        this.grafo = grafo;
    }

    public ListaEnlazada<Auto> getLista() {
        return lista;
    }

    public void setLista(ListaEnlazada<Auto> lista) {
        this.lista = lista;
    }

    private void llenarGrafo() {
        try {
            for (int i = 0; i < lista.size(); i++) {
                Auto auto = lista.get(i);
                HashMap<String, Double> mapa = new HashMap<>();
                System.out.println("AUTO " + auto.getNombre());
                ListaEnlazada<Radar> listaR = new RadarDao().listaAuto(auto.getId());
                for (int j = 0; j < listaR.size(); j++) {
                    Radar radar = listaR.get(j);
                    if (mapa.get(radar.getIdDestino()) != null) {
                        Double suma = mapa.get(radar.getIdDestino());
                        suma += radar.getDistancia();
                        mapa.put(radar.getIdDestino().toString(), suma);
                    } else {
                        mapa.put(radar.getIdDestino().toString(), Double.parseDouble(radar.getDistancia().toString()));
                    }
                }
                for (Map.Entry<String, Double> entry : mapa.entrySet()) {
                    Double distancia = entry.getValue();
                    Auto aux = getAuto(entry.getKey());
                    if (aux != null) {
                        System.out.println(aux);
                        grafo.insertarAristaE(auto, aux, distancia);
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Error de llenado: " + e);
            e.printStackTrace();
        }
    }

    private Auto getAuto(String radarr) throws VacioException, PosicionException {
        Auto aux = null;
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getId().equals(radarr)) {
                aux = lista.get(i);
                break;
            }
        }
        return aux;
    }

    //------------Algoritmo de PRIM--------------------//
    public GrafoEtiquetadoD<Auto> algoritmoPrim(Auto origen, Auto destino) {
        HashMap<Integer, ListaEnlazada<Radar>> conexionesRadar = new HashMap<>();

        try {
            Cola<Radar> cola = new Cola<>(lista.size()); // Crear una cola de radares

            // Obtener conexiones de radar para el auto origen
            ListaEnlazada<Radar> listaR = conexionesRadar.get(origen.getId());

            // Encolar las conexiones de radar
            for (int j = 0; j < listaR.size(); j++) {
                cola.queue(listaR.get(j));
            }

            while (!cola.isEmpty()) {
                Radar radar = cola.dequeue();
                Auto destinoObj = getAuto(radar.getIdDestino().toString());

                if (destinoObj != null) {
                    if (!grafo.existeAristaE(origen, destinoObj)) {
                        grafo.insertarAristaE(origen, destinoObj);
                    }
                    grafo.insertarAristaE(origen, destinoObj, radar.getDistancia());
                    break;
                }
            }
        } catch (Exception e) {
            System.out.println("Error en el algoritmo de Prim: " + e);
            e.printStackTrace();
        }

        return grafo;
    }

    //------------Calcular camino mas corto "Metodo Floyd"---------
    public ListaEnlazada<Auto> calcularCaminoMinimoFloyd(Auto origen, Auto destino) throws VacioException, PosicionException {
        int n = lista.size();
        HashMap<Auto, Integer> indiceMap = new HashMap<>();
        int indice = 1;

        for (int i = 0; i < lista.size(); i++) {
            Auto auto = lista.get(i);
            indiceMap.put(auto, indice);
            indice++;
        }

        double[][] distancias = new double[n + 1][n + 1];
        int[][] intermedios = new int[n + 1][n + 1];

        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                distancias[i][j] = Double.POSITIVE_INFINITY;
                intermedios[i][j] = -1;
            }
        }

        for (int i = 1; i <= n; i++) {
            distancias[i][i] = 0;
            Auto auto = lista.get(i - 1);
            ListaEnlazada<Radar> listaR = new RadarDao().listaAuto(auto.getId());
            for (int j = 0; j < listaR.size(); j++) {
                Radar radar = listaR.get(j);
                Auto destinoAuto = getAutoPorNroRadar(radar.getIdDestino().toString());
                if (destinoAuto != null) {
                    distancias[i][indiceMap.get(destinoAuto)] = radar.getDistancia();
                    intermedios[i][indiceMap.get(destinoAuto)] = i;
                }
            }
        }
        for (int k = 1; k <= n; k++) {
            for (int i = 1; i <= n; i++) {
                for (int j = 1; j <= n; j++) {
                    double distanciaIK = distancias[i][k];
                    double distanciaKJ = distancias[k][j];

                    if (distanciaIK != Double.POSITIVE_INFINITY && distanciaKJ != Double.POSITIVE_INFINITY) {
                        double distanciaIJ = distancias[i][j];
                        double nuevaDistancia = distanciaIK + distanciaKJ;

                        if (nuevaDistancia < distanciaIJ) {
                            distancias[i][j] = nuevaDistancia;
                            intermedios[i][j] = intermedios[k][j];
                        }
                    }
                }
            }
        }
        ListaEnlazada<Auto> caminoMinimo = reconstruirCamino(indiceMap.get(origen), indiceMap.get(destino), intermedios);

        if (caminoMinimo.isEmpty()) {
            System.out.println("\nNO EXISTE UN CAMINO MINIMO ENTRE " + origen.getNombre() + " Y " + destino.getNombre());
        } else {
            System.out.println("\nCAMINO MINIMO POR FLOYD ENTRE " + origen.getNombre() + " Y " + destino.getNombre() + ":");
            for (int i = 0; i < caminoMinimo.size(); i++) {
                System.out.println(caminoMinimo.get(i));
            }
        }

        return caminoMinimo;
    }

    private ListaEnlazada<Auto> reconstruirCamino(int origen, int destino, int[][] intermedios) throws VacioException, PosicionException {
        ListaEnlazada<Auto> camino = new ListaEnlazada<>();
        if (intermedios[origen][destino] == -1) {
            return camino;
        }
        camino.insertarAlInicio(lista.get(destino - 1));
        while (origen != destino) {
            destino = intermedios[origen][destino];
            camino.insertarAlInicio(lista.get(destino - 1));
        }
        return camino;
    }

    private Auto getAutoPorNroRadar(String nroRadar) throws VacioException, PosicionException {
        for (int i = 0; i < lista.size(); i++) {
            Auto auto = lista.get(i);
            if (auto.getId().equals(nroRadar)) {
                return auto;
            }
        }
        return null;
    }

    //------Algoritmo de busqueda en profundidad-------
    public boolean esConectado() throws VacioException, PosicionException {
        if (grafo.numVertices() == 0) {
            return false; // El grafo vacío no está conectado
        }

        HashSet<Auto> visitados = new HashSet<>();
        ListaEnlazada<Adycencia> adycentes = grafo.adyacentesGE(grafo.getEtiqueta(1)); // Comenzar la búsqueda desde el primer vértice

        dfs(grafo.getEtiqueta(1), visitados); // Realizar búsqueda DFS desde el primer vértice

        return visitados.size() == grafo.numVertices(); // Si se visitaron todos los vértices, el grafo está conectado
    }

    private void dfs(Auto vertice, HashSet<Auto> visitados) throws VacioException, PosicionException {
        visitados.add(vertice);
        ListaEnlazada<Adycencia> adycentes = grafo.adyacentesGE(vertice);

        for (int i = 0; i < adycentes.size(); i++) {
            Adycencia ady = adycentes.get(i);
            Auto verticeDestino = grafo.getEtiqueta(ady.getDestino());
            if (!visitados.contains(verticeDestino)) {
                dfs(verticeDestino, visitados);
            }
        }
    }

    public static void main(String[] args) {
        AutoGrafo pg = new AutoGrafo();

        try {
            boolean esConectado = pg.esConectado();
            if (esConectado) {
                System.out.println("El grafo está conectado.");
            } else {
                System.out.println("El grafo no está conectado.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
