/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import controlador.Dao.AutoDao;
import controlador.Dao.RadarDao;

public class Control {

    public static void main(String[] args) {
        try {

            AutoDao ad = new AutoDao();
//            ad.getAuto().setCordX(3);
//            ad.getAuto().setCordY(2);
//            ad.guardar();
            RadarDao rd = new RadarDao();
            
            
            rd.getRadar().setIdOrigen(1);
            rd.getRadar().setIdDestino(2);
            rd.getRadar().setDistancia(Double.NaN);
            rd.guardar();
            

        } catch (Exception e) {
        }
    }

}
